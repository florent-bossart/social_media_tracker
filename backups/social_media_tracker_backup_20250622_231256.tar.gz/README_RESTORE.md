# Database Backup Restore Guide

This backup contains a complete snapshot of the Social Media Tracker database.

## Quick Restore

```bash
# Extract backup
tar -xzf social_media_tracker_backup_20250622_231256.tar.gz

# Restore to PostgreSQL (adjust connection details as needed)
psql -h localhost -p 5432 -U postgres -d postgres -f social_media_tracker_backup_20250622_231256.sql
```

## Docker Restore

If using the provided Docker Compose setup:

```bash
# Start PostgreSQL container
docker-compose up postgres -d

# Wait for PostgreSQL to be ready
sleep 10

# Restore database
docker exec -i social_media_tracker-postgres-1 psql -U postgres -d postgres < social_media_tracker_backup_20250622_231256.sql
```

## Environment Setup

After restoring the database, make sure to:

1. Copy `env_file.example` to `.env`
2. Update database credentials in `.env`
3. Install dependencies: `poetry install`
4. Start services: `docker-compose up`

## Schemas Included

- **raw**: Raw API data (YouTube comments, Reddit posts)
- **staging**: Cleaned and processed data
- **analytics**: Aggregated insights and trends

## Data Included

This backup contains sample data for Japanese music trend analysis including:
- YouTube comments and metadata
- Reddit posts and discussions
- Sentiment analysis results
- Entity extraction data
- Temporal trends and analytics

Perfect for getting started with the social media analytics pipeline!
